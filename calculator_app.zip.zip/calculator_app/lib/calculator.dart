import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';
import 'dart:math';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
   CalculatorScreenState createState() => CalculatorScreenState();
}

class CalculatorScreenState extends State<CalculatorScreen> {
  String expression = '';
  String result = '0';

  void onButtonPressed(String buttonText) {
    setState(() {
      if (buttonText == 'C') {
        expression = '';
        result = '0';
      } else if (buttonText == '=') {
        try {
          GrammarParser p = GrammarParser();
          Expression exp = p.parse(expression);
          ContextModel cm = ContextModel();
          double eval = exp.evaluate(EvaluationType.REAL, cm);
          result = eval.toString();
          expression = result; // Keep the result for further calculations
        } catch (e) {
          result = 'Error';
        }
      } else if (buttonText == '√') {
        try {
          double num = double.parse(expression);
          result = (num >= 0) ? sqrt(num).toString() : 'Error';
          expression = result;
        } catch (e) {
          result = 'Error';
        }
      } else if (buttonText == 'sin' ||
          buttonText == 'cos' ||
          buttonText == 'tan' ||
          buttonText == 'log') {
        try {
          double num = double.parse(expression);
          if (buttonText == 'sin') result = sin(num*pi/180).toString();
          if (buttonText == 'cos') result = cos(num*pi/180).toString();
          if (buttonText == 'tan') result = tan(num*pi/180).toString();
          if (buttonText == 'log') result = (num > 0) ? log(num).toString() : 'Error';
          expression = result;
        } catch (e) {
          result = 'Error';
        }
      } else {
        expression += buttonText;
      }
    });
  }

  Widget buildButton(String text, Color color) {
    return Expanded(
      child: ElevatedButton(
        onPressed: () => onButtonPressed(text),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.all(20),
          backgroundColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(fontSize: 24, color: Colors.white),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    expression,
                    style: const TextStyle(fontSize: 32, color: Colors.white),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    result,
                    style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          const Divider(color: Colors.white),
          Column(
            children: [
              buildRow(['sin', 'cos', 'tan', 'log']),
              buildRow(['7', '8', '9', '/']),
              buildRow(['4', '5', '6', '*']),
              buildRow(['1', '2', '3', '-']),
              buildRow(['C', '0', '=', '+']),
              buildRow(['√']),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildRow(List<String> buttons) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: buttons.map((text) {
        Color color = (text == '=' || text == '√') ? Colors.green : (text == 'C' ? Colors.red : Colors.grey);
        return buildButton(text, color);
      }).toList(),
    );
  }
}